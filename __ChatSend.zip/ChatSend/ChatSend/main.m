//
//  main.m
//  ChatSend
//
//  Created by evx on 5/1/14.
//  Copyright (c) 2014 evxyz001. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "EVXAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([EVXAppDelegate class]));
    }
}
